<img src="{{ $singleVideo->video_futured_image }}"  alt="Image" class="img-fluid rounded mr-3">
<div>
    <h5 class="modal-title" id="exampleModalLabel">Please  pay {{ $singleVideo->video_price }} to unlock this video</h5>
    <button type="button" class="btn btn-secondary">Unlock Now</button>
</div>
