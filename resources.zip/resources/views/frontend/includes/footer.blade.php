<!--Footer Area -->
<!--  -->
<div class="copyright2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="copy-text">
                    <p>Copyright &copy; 2021. All rights reserved</p>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6">
                <div class="copy-nav">
                    <ul>
                        <li><a href="{{ route('privacy.policy') }}">Privacy</a></li>
                        <li><a href="{{ route('contact.us') }}">Contact</a></li>
                        <li><a href="{{ route('terms.condition') }}">Terms & service</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div><!--/Footer Area-->

